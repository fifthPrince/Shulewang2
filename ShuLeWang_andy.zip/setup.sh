alias node /proj/mpsw_arm/ehuajig/node-v6.9.1-linux-x64/bin/node
alias npm /proj/mpsw_arm/ehuajig/node-v6.9.1-linux-x64/bin/npm


