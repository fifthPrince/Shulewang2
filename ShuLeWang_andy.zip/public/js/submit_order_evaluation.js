
var dbop = require('./dbOperation.js');

function order_eval() {

  var shape_score=3;
  var taste_score=3;
  var logistic_score=3;
  var service_score=3;
  var shape_score_HtmlCol = document.getEementsByName(“rb_shape”);
  for(var i = 0; i < shape_score_HtmlCol.length; i++)
  {
	  if(shape_score_HtmlCol[i].checked)
	  {
		  shape_score = shape_score_HtmlCol[i].value;
		  break;
	  }
  }
  for(var i = 0; i < taste_score_HtmlCol.length; i++)
  {
	  if(taste_score_HtmlCol[i].checked)
	  {
		  taste_score = taste_score_HtmlCol[i].value;
		  break;
	  }
  }
  for(var i = 0; i < logistic_score_HtmlCol.length; i++)
  {
	  if(logistic_score_HtmlCol[i].checked)
	  {
		  logistic_score = logistic_score_HtmlCol[i].value;
		  break;
	  }
  }
  for(var i = 0; i < service_score_HtmlCol.length; i++)
  {
	  if(service_score_HtmlCol[i].checked)
	  {
		  service_score = service_score_HtmlCol[i].value;
		  break;
	  }
  }
  
  var person_id;
  var product_id;

}

