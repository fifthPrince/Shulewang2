How to setup and run:
1. Install nodejs for your OS
2. Run command to install node modules
   > npm install
3. Start up app
   > node server.js